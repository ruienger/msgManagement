<?php

header('Content-Type:application/json');//这个类型声明非常关键
echo '{"code":1,"msg":"操作成功","data":{"id":"407","filepath":"\/uploads\/article\/20190717\/6c25fd31c7821214a991bd9323e1d303.jpg"},"url":"","wait":3}';